/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package chatapplication;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;
/**
 *
 * @author RC_Student_lab
 */
//User class to store information
class User{
    private String firstName;
    private String lastName;
    private String Cellphone;
    private String username;
    private String password;
    
    public User(String firstName,String lastName,String Cellphone,String username,String password){
        this.firstName= firstName;
        this.lastName= lastName;
        this.Cellphone= Cellphone;
        this.username= username;
        this.password= password;
    }
 //Getters and setters
    public String getUsername(){
        return username;
    }
    public String getPassword(){
        return password;
    }
    public String getFirstName(){
        return firstName;
    }
    public String getLastName(){
        return lastName;
    }
    public String getCellPhone(){
        return Cellphone;
    }
    @Override
    public String toString(){
        return """
               User Details:
               First Name"""+firstName+"\n"+
                "Last Name"+lastName +"\n"+
                "Cellphone"+Cellphone+"\n"+
                "Username"+username;
    }
    //Message class to show chat messages
    class Messager{
        private String senderPhone;
        private String recieverPhone;
        private String payload;
        private boolean sent;
        private boolean receieved;
        private boolean read;
        
        public Messager(String senderPhone,String recieverPhone,String payload){
            this.senderPhone=senderPhone;
            this.recieverPhone=recieverPhone;
            this.payload=payload;
            this.read=false;
            this.receieved=false;
            this.sent=false;
        }
     //Getter and setters
        public String getSenderPhone(){
            return senderPhone;
        }
        public String getReceieverPhone(){
            return recieverPhone;
        }
        public String getPayload(){
            return payload;
        }
        public boolean isSent(){
            return sent;
        }
        public boolean isRecieved(){
            return receieved;
        }
        public boolean isRead(){
            return read;
        }
        
        public void MarkAsSent(){
            this.sent=true;
        }
        public void MarkAsRecieved(){
            this.receieved=true;
        }
        public void MarkAsRead(){
            this.read=true;
        }
        @Override
        public String toString(){
            return"Message from"+ senderPhone+"to"+recieverPhone+"\n+"+
                    payload+"\n"+
                    "Status"+(sent?"Sent":"")+
                    (receieved?"Received":"")+
                    (read?"Read":"");
        }
    }
}
//Main application and Registration, login and chat functionality
public class ChatApplication{
private static ArrayList<User>users=new ArrayList<>();
private static final ArrayList<Messager>messages=new ArrayList<>();
private static Scanner scanner=new Scanner(System.in);
private static User currentUser=null;
//Main Application
public static void main(String[]args){
 boolean running=true;
 
 while(running){
     if(currentUser==null){
         showMainMenu();
     }else{
         showChatMenu();
     }
 }
}
//Main Menu
private static void showMainMenu(){
    System.out.println("Welcome to Chat App");
    System.out.println("1.Register");
    System.out.println("2.Login");
    System.out.println("3.Exit");
    System.out.println("Please choose an Option");
    
    int choice= getIntInput();
    switch(choice){
        case 1:
            registerUser();
        case 2:
            loginUser();
            break;
        case 3:
            System.out.println("Exiting the system,Goodbye");
            System.exit(0);
            break;
        default:
            System.out.println("Invalid Option. Please choose the correct one");
    }
    }
//Chat menu
private static void showChatMenu(){
   System.out.println("Chat Menu"); 
   System.out.println("1.Send Messages");
   System.out.println("2.View Messages");
   System.out.println("3.Login");
   System.out.println("Choose an Option:");
   
   int choice= getIntInput();
   
   switch(choice){
       case 1:
           sendMessage();
           break;
       case 2:
           viewMessage();
           break;
       case 3:
           currentUser=null;
           System.out.println("Logged out successfully.");
           break;
       default:
           System.out.println("Invalid Option, please try again.");
   }
}
//Register user
private static void registerUser(){
    System.out.println("User Registration");
    
    String firstName=getInput("Enter your first name:" ,false);
    String lastName=getInput("Enter your last name:", false);
    
    String Cellphone= getInput("Enter Cellphone(e.g.,+27123456789):",true,"^\\+27\\d{9}$","Invalid SA number format.Please use +27 followed by 9 digits ");
    
    String username=getInput("Enter a username(must contain underscore and be 5 characters or less):",true,"^{1,5}_.*$","Username must contain underscore and be =<5 characters.");
    
    String password=getInput("Enter password( min 8 characters, with uppercase,a number):",true,"^(?=.*[A-Z])(?=.*\\d.{8,}$)","Password must be =>8 Characters with an Uppercase and 1 number");
    //Check if Username already exists
    if(isUsernameTaken(username)){
        System.out.println("Username already taken.Please choose another.");
        return;
    }
    users.add(new User(firstName, lastName,Cellphone, username, password));
    System.out.println("Registration successful!Ypu can now login");
}
private static boolean isUsernameTaken(String username){
    for(User user:users){
        if(user.getUsername().equals(username)){
            return true;
        }
    }
    return false;
    }
private static void loginUser(){
    System.out.println("User Login");
    if(users.isEmpty()){
        System.out.println("No user registered, Please Register");
        return;
    }
   String username=getInput("Enter your username:",false);
   String password=getInput("Enter your password:",false);
   
   for(User user:users){
       if(user.getUsername().equals(username)&& user.getPassword().equals(password)){
       currentUser=user;
       System.out.println("Login Successful1!");
       System.out.println("Welcome"+ user.getFirstName()+""+user.getLastName()+",it is great to see you again!");
       return;
   }
   }
   System.out.println("Invalid Password,Please try again");
}
private static void sendMessage(){
    System.out.println("Send Message");
    String recieverPhone=getInput("Enter recipient's phone number(+27 format):" ,true,"^\\+27\\d{9}$","Invalid Number format. Please use correct format followed by 9 digits");
    
    String payload=getInput("Enter your message:",false);
    Messager message=new Messager(currentUser.getCellPhone(),recieverPhone,payload);
    message.markAsSent();
    message.add(message);
   
    System.out.println("Message sent successfully!");
}
private static void viewMessage(){
    System.out.println("Your messages");
    boolean foundMessage=false;
    
    for(Messager message:messages){
        if(message.getRecieverPhone().equals(currentUser.getCellPhone())){
            foundMessage=false;
            message.markAsReceived();
            message.MarkAsRead();
            System.out.println(message);
            System.out.println("------");
        }
    }
    if(!foundMessage){
        System.out.println("You have no messages.");
    }
}
//Helper Methods
private static String getInput(String prompt,boolean validate,String regex,String errorMessage){
    String input;
    while(true){
        System.out.print(prompt);
        input=scanner.nextLine().trim();
        
        if(input.isEmpty()){
           System.out.println("input cannoy be empty. Please try again");
           continue;
        }
        if(validate&&!Pattern.matches(regex, input)){
            System.out.println(errorMessage);
            continue;
        }
        break;
    }
    return input;
}
private static String getInput(String prompt, boolean checkLength){
    return getInput(prompt,false,"","");
}

private static int getIntInput(){
    while(true){
        try{
            return Integer.parseInt(scanner.nextLine());
        } catch(NumberFormatException e){
            System.out.println("Invalid input.Please enter a number.");
            System.out.println("Try again");
        }
    }
}

    private static class Messager {

        public Messager() {
        }

        private Messager(String cellPhone, String recieverPhone, String payload) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private void MarkAsRead() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private void markAsReceived() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private Object getRecieverPhone() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private void add(Messager message) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private void markAsSent() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
}
