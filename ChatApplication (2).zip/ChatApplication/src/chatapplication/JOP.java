/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapplication;
import javax.swing.JOptionPane;
/**
 *
 * @author RC_Student_lab
 */
public class JOP{
public class MainMenu{
    private final User currentUser;

    public MainMenu(User currentUser) {
        this.currentUser = currentUser;
    }

    public void show() {
        while (true) {
            String[] options = {"View Messages", "Edit Profile", "Continue to Messaging", "Exit"};
            int choice = JOptionPane.showOptionDialog(
                null,
                "Welcome to QuickChat, " + currentUser.getFirstName() + "!\nChoose an option:",
                "QuickChat Menu",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                options,
                options[0]
            );
            switch (choice) {
                case 0: // View Messages
                    String messages = Message.printMessages();
                    JOptionPane.showMessageDialog(null, messages.isEmpty() ? "No messages available." : messages, "Stored Messages", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 1: // Edit Profile
                    editProfile();
                    break;
                case 2: // Continue to Messaging
                    return; // Exit the menu to proceed to messaging
                case 3: // Exit
                    JOptionPane.showMessageDialog(null, "Thank you for using QuickChat!", "Goodbye", JOptionPane.INFORMATION_MESSAGE);
                    System.exit(0);
                    break;
                default: // Dialog closed
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void editProfile() {
        String firstName = getInput("Enter new first name (or leave blank to keep current):", false, "", "");
        if (firstName != null && !firstName.trim().isEmpty()) {
            currentUser.setFirstName(firstName);
        }
        String lastName = getInput("Enter new last name (or leave blank to keep current):", false, "", "");
        if (lastName != null && !lastName.trim().isEmpty()) {
            currentUser.setLastName(lastName);
        }
        String cellPhoneNumber = getInput("Enter new cell phone number (must start with +27, or leave blank to keep current):", true,
                "^\\+27\\d{9}$|^$", "Invalid SA number format. Please use +27 followed by 9 digits or leave blank.");
        if (cellPhoneNumber != null && !cellPhoneNumber.trim().isEmpty()) {
            currentUser.setCellPhoneNumber(cellPhoneNumber);
        }
        JOptionPane.showMessageDialog(null, "Profile updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    private String getInput(String prompt, boolean validate, String regex, String errorMessage) {
        String input;
        while (true) {
            input = JOptionPane.showInputDialog(null, prompt, "QuickChat", JOptionPane.PLAIN_MESSAGE);
            if (input == null) {
                return null; // User clicked Cancel
            }
            if (input.trim().isEmpty() && !validate) {
                return input; // Allow empty input if no validation
            }
            if (input.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Input cannot be empty. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                continue;
            }
            if (validate && !input.matches(regex)) {
                JOptionPane.showMessageDialog(null, errorMessage, "Error", JOptionPane.ERROR_MESSAGE);
                continue;
            }
            return input;
        }
    }
}
