/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package chatapplication;
/**
 *
 * @author RC_Student_lab
 */

import java.util.ArrayList;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

class User {
    private String firstName;
    private String lastName;
    private String cellphone;
    private String username;
    private String password;

    public User(String firstName, String lastName, String cellphone, String username, String password) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.cellphone = cellphone;
        this.username = username;
        this.password = password;
    }

    // Getters
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getCellphone() {
        return cellphone;
    }

    // Setters
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setCellphone(String cellphone) {
        this.cellphone = cellphone;
    }

    @Override
    public String toString() {
        return "User Details:\n" +
               "First Name: " + firstName + "\n" +
               "Last Name: " + lastName + "\n" +
               "Cellphone: " + cellphone + "\n" +
               "Username: " + username;
    }
}

public class ChatApplication {
    private static ArrayList<User> users = new ArrayList<>();
    private static User currentUser = null;

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat!", "QuickChat", JOptionPane.INFORMATION_MESSAGE);
        boolean running = true;
        while (running) {
            if (currentUser == null) {
                showMainMenu();
            } else {
                showChatMenu();
            }
        }
    }

    private static void showMainMenu() {
        String[] options = {"Register", "Login", "Exit"};
        int choice = JOptionPane.showOptionDialog(
            null,
            "Welcome to Chat App\nPlease choose an option:",
            "QuickChat",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.PLAIN_MESSAGE,
            null,
            options,
            options[0]
        );
        switch (choice) {
            case 0: // Register
                registerUser();
                break;
            case 1: // Login
                loginUser();
                break;
            case 2: // Exit
                JOptionPane.showMessageDialog(null, "Exiting QuickChat. Goodbye!", "Exit", JOptionPane.INFORMATION_MESSAGE);
                System.exit(0);
                break;
            default: // Dialog closed
                JOptionPane.showMessageDialog(null, "Invalid option. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void showChatMenu() {
        String[] options = {"Send Messages", "View Messages", "Logout", "Exit"};
        int choice = JOptionPane.showOptionDialog(
            null,
            "Chat Menu\nChoose an option:",
            "QuickChat",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.PLAIN_MESSAGE,
            null,
            options,
            options[0]
        );
        switch (choice) {
            case 0: // Send Messages
                int numMessages = getIntInput("How many messages would you like to send?");
                if (numMessages <= 0) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid number of messages.", "Error", JQueryPane.ERROR_MESSAGE);
                    break;
                }
                for (int i = 0; i < numMessages; i++) {
                    if (!sendMessage()) {
                        JOptionPane.showMessageDialog(null, "Message sending cancelled.", "Info", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                JOptionPane.showMessageDialog(null, "Total messages sent: " + Message.returnTotalMessages(), "Info", JOptionPane.INFORMATION_MESSAGE);
                break;
            case 1: // View Messages
                JOptionPane.showMessageDialog(null, Message.printMessages(), "Messages", JOptionPane.INFORMATION_MESSAGE);
                break;
            case 2: // Logout
                currentUser = null;
                JOptionPane.showMessageDialog(null, "Logged out successfully.", "Info", JOptionPane.INFORMATION_MESSAGE);
                break;
            case 3: // Exit
                JOptionPane.showMessageDialog(null, "Exiting QuickChat. Total messages sent: " + Message.returnTotalMessages(), "Exit", JOptionPane.INFORMATION_MESSAGE);
                System.exit(0);
                break;
            default: // Dialog closed
                JOptionPane.showMessageDialog(null, "Invalid option. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void registerUser() {
        String firstName = getInput("Enter your first name:", false, "", "");
        if (firstName == null) {
            JOptionPane.showMessageDialog(null, "Registration cancelled.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        String lastName = getInput("Enter your last name:", false, "", "");
        if (lastName == null) {
            JOptionPane.showMessageDialog(null, "Registration cancelled.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        String cellphone = getInput("Enter cellphone (e.g., +27123456789):", true,
                "^\\+27\\d{9}$", "Invalid SA number format. Please use +27 followed by 9 digits");
        if (cellphone == null) {
            JOptionPane.showMessageDialog(null, "Registration cancelled.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        String username = getInput("Enter a username (must contain underscore and be 5 characters or less before _):", true,
                "^[a-zA-Z0-9]{1,5}_[a-zA-Z0-9]*$", "Username must contain underscore and be <=5 characters before underscore.");
        if (username == null) {
            JOptionPane.showMessageDialog(null, "Registration cancelled.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        String password = getInput("Enter password (min 8 characters, with uppercase, number):", true,
                "^(?=.*[A-Z])(?=.*\\d).{8,}$", "Password must be >=8 characters with an uppercase and 1 number");
        if (password == null) {
            JOptionPane.showMessageDialog(null, "Registration cancelled.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if (isUsernameTaken(username)) {
            JOptionPane.showMessageDialog(null, "Username already taken. Please choose another.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        users.add(new User(firstName, lastName, cellphone, username, password));
        JOptionPane.showMessageDialog(null, "Registration successful! You can now login.", "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    private static boolean isUsernameTaken(String username) {
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return true;
            }
        }
        return false;
    }

    private static void loginUser() {
        if (users.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No users registered. Please register first.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String username = getInput("Enter your username:", false, "", "");
        if (username == null) {
            JOptionPane.showMessageDialog(null, "Login cancelled.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        String password = getInput("Enter your password:", false, "", "");
        if (password == null) {
            JOptionPane.showMessageDialog(null, "Login cancelled.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                currentUser = user;
                JOptionPane.showMessageDialog(null, "Login successful!\nWelcome " + user.getFirstName() + " " + user.getLastName() + ", it is great to see you again!", "Success", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Invalid username or password. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
    }

    private static boolean sendMessage() {
        String recipientPhone = getInput("Enter recipient's phone number (+27 format):", true,
                "^\\+27\\d{9}$", "Invalid number format. Please use +27 followed by 9 digits");
        if (recipientPhone == null) {
            return false; // Cancelled
        }
        String payload = getInput("Enter your message (max 250 characters):", true,
                "^.{1,250}$", "Message must be 1 to 250 characters.");
        if (payload == null) {
            return false; // Cancelled
        }
        Message message = new Message(recipientPhone, payload);
        if (!message.checkMessageID() || !message.checkRecipientCell()) {
            JOptionPane.showMessageDialog(null, "Invalid message ID or recipient cell number.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        JOptionPane.showMessageDialog(null, message.sendMessage(), "Message Status", JOptionPane.INFORMATION_MESSAGE);
        return true;
    }

    private static String getInput(String prompt, boolean validate, String regex, String errorMessage) {
        String input;
        while (true) {
            input = JOptionPane.showInputDialog(null, prompt, "QuickChat", JOptionPane.PLAIN_MESSAGE);
            if (input == null) {
                return null; // User clicked Cancel
            }
            if (input.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Input cannot be empty. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                continue;
            }
            if (validate && !Pattern.matches(regex, input)) {
                JOptionPane.showMessageDialog(null, errorMessage, "Error", JOptionPane.ERROR_MESSAGE);
                continue;
            }
            return input;
        }
    }

    private static int getIntInput(String prompt) {
        while (true) {
            String input = JOptionPane.showInputDialog(null, prompt, "QuickChat", JOptionPane.PLAIN_MESSAGE);
            if (input == null) {
                return -1; // Indicate cancellation
            }
            try {
                return Integer.parseInt(input.trim());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}