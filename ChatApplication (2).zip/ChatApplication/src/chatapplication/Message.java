/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapplication;

/**
 *
 * @author RC_Student_lab
 */
class Message {

    Message(String recipientPhone, String payload) {
    }

    static String printMessages() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static String returnTotalMessages() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static String returnTotalMessages() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    boolean checkMessageID() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    boolean checkRecipientCell() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    Object sendMessage() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    class Messager {
    private String senderPhone;
    private String receiverPhone;
    private String payload;
    private boolean sent;
    private boolean received;
    private boolean read;

    public Messager(String senderPhone, String receiverPhone, String payload) {
        this.senderPhone = senderPhone;
        this.receiverPhone = receiverPhone;
        this.payload = payload;
        this.sent = false;
        this.received = false;
        this.read = false;
    }

    public String getReceiverPhone() {
        return receiverPhone;
    }

    public void markAsSent() {
        this.sent = true;
    }

    public void markAsReceived() {
        this.received = true;
    }

    public void markAsRead() {
        this.read = true;
    }
    }
